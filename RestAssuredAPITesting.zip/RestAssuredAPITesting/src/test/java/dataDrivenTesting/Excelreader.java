package dataDrivenTesting;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelreader {

	public static FileInputStream file;
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static int rowcount;
	public static int columncount;
	static String data;
	static Properties prop;
	

	public void a() throws IOException {
		try {
			FileInputStream fs = new FileInputStream(System.getProperty("user.dir")	+ "//src//test//java//dataSource//URI.properties");
			prop.load(fs);
			String env = prop.getProperty("Excelpath");
						
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public static int getRowCount(String filepath, String Sheetname) {
		
		try {
			file = new FileInputStream(filepath);
			workbook = new XSSFWorkbook(file);
			sheet = workbook.getSheet(Sheetname);
			rowcount = sheet.getLastRowNum();
			workbook.close();
			file.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return rowcount;
	}

	public static int getcolumncount(String filepath, String Sheetname, int rowcount) {
		try {
			file = new FileInputStream(filepath);
			workbook = new XSSFWorkbook(file);
			sheet = workbook.getSheet(Sheetname);
			XSSFRow row = sheet.getRow(rowcount);
			columncount = row.getLastCellNum();
			workbook.close();
			file.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return columncount;
	}

	public static String getcelldata(String filepath, String Sheetname, int rownum, int columnnum) {
		try {
			file = new FileInputStream(filepath);
			workbook = new XSSFWorkbook(file);
			sheet = workbook.getSheet(Sheetname);
			XSSFRow row = sheet.getRow(rownum);
			XSSFCell cell = row.getCell(columnnum);

			try {
				DataFormatter formatter = new DataFormatter();
				String cellData = formatter.formatCellValue(cell);
				return cellData;

			} catch (Exception e) {
				data = "";
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return data;

	}
	
	public static String propfile(String data) throws IOException {
		String object = null;
		try {
		
			Properties obj = new Properties();					
		    FileInputStream objfile = new FileInputStream(System.getProperty("user.dir")+"//src//test//java//dataSource//URI.properties");
		    obj.load(objfile);	
		    object =  obj.getProperty(data);
		    System.out.println(object);	
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return object;
	}

}
