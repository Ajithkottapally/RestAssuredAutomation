package dataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.junit.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CountryToCapital {
	static Properties prop;
	
	/*@ this method will use the data from DataProvider and process the request
	 * 
	 */
	@Test(dataProvider="Country")
	void getresponse(String ecountry, String capital) throws IOException {
		
		try {
		
		String URI = Excelreader.propfile("countryURI");
		URI = URI.replace("{country}",ecountry);
		RestAssured.baseURI = URI;
		
//		Request Object
		RequestSpecification httprequest = RestAssured.given();
		
//		Response Object
		Response response = httprequest.request(Method.GET,"/");
		
//		Print Response in console window
		String ResponseBody = response.getBody().asString();
		
//		Status code Validation
		int StatusCode = response.getStatusCode();
		Assert.assertEquals(StatusCode, 200);
		
//		Status Line Validation
		String StatusLine = response.getStatusLine();
		System.out.println("StatusLine: "+ StatusLine);
		Assert.assertEquals(StatusLine, "HTTP/1.1 200 ");
	
//		Header Validation 
		String Header = response.header("Content-Type");
		Assert.assertEquals(Header, "application/json;charset=utf-8");
		
//		Json Object
		JsonPath jsonpath = response.jsonPath();
		System.out.println("Contry Capital of  "+ecountry +" is :" +jsonpath.get("capital") );
		
//		Extracting the node value from json object
		ArrayList<String> Expected = jsonpath.get("capital");
		Assert.assertEquals(Expected.get(0), capital);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	/* @ this step is to get the data from Excel and store/return it in an Array.
	 * 
	 */
	@DataProvider(name="Country")
	 String[][]  getCountryData() throws IOException {
		String path = System.getProperty("user.dir")+ "/src/test/java/dataSource/testData.xlsx";
		int rownum = Excelreader.getRowCount(path, "Sheet1");
		int colcount = Excelreader.getcolumncount(path,"Sheet1", 1);
		String data[][] = new String[rownum][colcount] ;
		for(int i = 1; i<= rownum; i++) {
			for (int j = 0; j < colcount; j++) {
				data[i -1][j] = Excelreader.getcelldata(path, "Sheet1", i, j);	
			}			
		}
		return(data);		
	}

}
